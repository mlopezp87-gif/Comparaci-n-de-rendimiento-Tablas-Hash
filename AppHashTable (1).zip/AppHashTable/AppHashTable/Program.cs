﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Diagnostics;

namespace AppHashTable
{
    public class Program
    {
        static void Main(string[] args)
        {
            const int CANTIDAD_MAXIMA = 150000;  
            int cantidadActual = 100000;        

            
            int[] arregloIds = new int[CANTIDAD_MAXIMA];
            string[] arregloNombres = new string[CANTIDAD_MAXIMA];

            
            Dictionary<int, string> diccionarioEstudiantes = new Dictionary<int, string>();

            
            for (int i = 0; i < cantidadActual; i++)
            {
                int idGenerado = 100000 + i; 
                string nombreGenerado = $"Estudiante_Anonimo_{i + 1}";

                
                arregloIds[i] = idGenerado;
                arregloNombres[i] = nombreGenerado;

                
                diccionarioEstudiantes.Add(idGenerado, nombreGenerado);
            }

            string opcion = "";

            
            while (opcion != "5")
            {
                Console.Clear();
                Console.WriteLine("Seleccione una opción:");
                Console.WriteLine("1. alamcenar"); 
                Console.WriteLine("2. Buscar ");
                Console.WriteLine("3. Actualizar");
                Console.WriteLine("4. Eliminar");
                Console.WriteLine("5. Salir");
                Console.Write("\nOpción: ");
                opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1": 
                        Console.Write("\n Ingrese el codigo del nuevo estudiante: ");
                        if (!int.TryParse(Console.ReadLine(), out int nuevoId))
                        {
                            Console.WriteLine("Codigo no válido.");
                            break;
                        }

                        
                        if (diccionarioEstudiantes.ContainsKey(nuevoId))
                        {
                            Console.WriteLine("Error: El codigo ya existe.");
                        }
                        else if (cantidadActual >= CANTIDAD_MAXIMA)
                        {
                            Console.WriteLine("Error: Arreglo lleno.");
                        }
                        else
                        {
                            Console.Write("Ingrese el nombre del estudiante: ");
                            string nuevoNombre = Console.ReadLine();

                            
                            arregloIds[cantidadActual] = nuevoId;
                            arregloNombres[cantidadActual] = nuevoNombre;

                            
                            diccionarioEstudiantes.Add(nuevoId, nuevoNombre);

                            cantidadActual++; 
                            Console.WriteLine("Estudiante almacenado en ambas estructuras.");
                        }
                        break;

                    case "2": 
                        Console.Write("\n Ingrese el codigo a buscar: ");
                        if (!int.TryParse(Console.ReadLine(), out int idBuscar))
                        {
                            Console.WriteLine("Codigo no válido.");
                            break;
                        }

                        Stopwatch stopwatch = new Stopwatch();

                        
                        string resultadoArreglo = "No encontrado";
                        stopwatch.Start();
                        for (int i = 0; i < cantidadActual; i++)
                        {
                            if (arregloIds[i] == idBuscar)
                            {
                                resultadoArreglo = arregloNombres[i];
                                break;
                            }
                        }
                        stopwatch.Stop();
                        long tiempoArregloTicks = stopwatch.ElapsedTicks;
                        double tiempoArregloMs = stopwatch.Elapsed.TotalMilliseconds;

                        stopwatch.Reset();

                        
                        string resultadoDiccionario = "No encontrado";
                        stopwatch.Start();
                        if (diccionarioEstudiantes.ContainsKey(idBuscar))
                        {
                            resultadoDiccionario = diccionarioEstudiantes[idBuscar];
                        }
                        stopwatch.Stop();
                        long tiempoDiccionarioTicks = stopwatch.ElapsedTicks;
                        double tiempoDiccionarioMs = stopwatch.Elapsed.TotalMilliseconds;

                        
                        Console.WriteLine("RESULTADOS DE LA BÚSQUEDA:");
                        Console.WriteLine($" En Arreglo:    {resultadoArreglo}");
                        Console.WriteLine($" En Dictionary: {resultadoDiccionario}");
                        Console.WriteLine("TIEMPOS DE EJECUCIÓN:");
                        Console.WriteLine($" Arreglo :   {tiempoArregloMs} ms ({tiempoArregloTicks} )");
                        Console.WriteLine($" Dictionary:  {tiempoDiccionarioMs} ms ({tiempoDiccionarioTicks} )");

                        if (resultadoDiccionario != "No encontrado" && tiempoDiccionarioTicks > 0)
                        {
                            double diferencia = (double)tiempoArregloTicks / tiempoDiccionarioTicks;
                            Console.WriteLine($" {diferencia:F2}");
                        }
                        break;

                    case "3": 
                        Console.Write("\n Ingrese el codigo del estudiante a modificar: ");
                        if (int.TryParse(Console.ReadLine(), out int idActualizar) && diccionarioEstudiantes.ContainsKey(idActualizar))
                        {
                            Console.Write("Ingrese el nuevo nombre: ");
                            string nuevoNombre = Console.ReadLine();

                            
                            diccionarioEstudiantes[idActualizar] = nuevoNombre;

                            
                            for (int i = 0; i < cantidadActual; i++)
                            {
                                if (arregloIds[i] == idActualizar)
                                {
                                    arregloNombres[i] = nuevoNombre;
                                    break;
                                }
                            }
                            Console.WriteLine("Estudiante actualizado correctamente en ambas estructuras.");
                        }
                        else
                        {
                            Console.WriteLine("El estudiante no existe.");
                        }
                        break;

                    case "4": 
                        Console.Write("\n[ELIMINAR] Ingrese el codigo del estudiante a eliminar: ");
                        if (int.TryParse(Console.ReadLine(), out int idEliminar) && diccionarioEstudiantes.ContainsKey(idEliminar))
                        {
                            
                            diccionarioEstudiantes.Remove(idEliminar);

                            
                            for (int i = 0; i < cantidadActual; i++)
                            {
                                if (arregloIds[i] == idEliminar)
                                {
                                    
                                    for (int j = i; j < cantidadActual - 1; j++)
                                    {
                                        arregloIds[j] = arregloIds[j + 1];
                                        arregloNombres[j] = arregloNombres[j + 1];
                                    }
                                    cantidadActual--;
                                    break;
                                }
                            }
                            Console.WriteLine("Estudiante eliminado correctamente de ambas estructuras.");
                        }
                        else
                        {
                            Console.WriteLine("El estudiante no existe.");
                        }
                        break;

                    case "5": 
                        Console.WriteLine("\nSaliendo del programa ");
                        break;

                    default:
                        Console.WriteLine("\nOpción inválida. Intente de nuevo.");
                        break;
                }

                if (opcion != "5")
                {
                    Console.WriteLine("\nPresione cualquier tecla para continuar...");
                    Console.ReadKey();
                }
            }
        }
    }
}
